package biblioteca;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Livro {
	
	@Id
	private Integer id;
	@Column(name="Título")
	private String titulo;
	@Column(name="Autor")
	private String autor;
	@Column(name="Editora")
	private String editora;
	@Column(name="Ano")
	private Integer ano;
	@Column(name="Páginas")
	private Integer paginas;
	@Column(name="Gênero")
	private String genero;
	@Column(name="ISBN")
	private Integer isbn;
	
	
	public Livro () {
		
		
	}


	public Livro(Integer id, String titulo, String autor, String editora, Integer ano, Integer paginas, String genero,
			Integer isbn) {
		super();
		this.id = id;
		this.titulo = titulo;
		this.autor = autor;
		this.editora = editora;
		this.ano = ano;
		this.paginas = paginas;
		this.genero = genero;
		this.isbn = isbn;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getTitulo() {
		return titulo;
	}


	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}


	public String getAutor() {
		return autor;
	}


	public void setAutor(String autor) {
		this.autor = autor;
	}


	public String getEditora() {
		return editora;
	}


	public void setEditora(String editora) {
		this.editora = editora;
	}


	public Integer getAno() {
		return ano;
	}


	public void setAno(Integer ano) {
		this.ano = ano;
	}


	public Integer getPaginas() {
		return paginas;
	}


	public void setPaginas(Integer paginas) {
		this.paginas = paginas;
	}


	public String getGenero() {
		return genero;
	}


	public void setGenero(String genero) {
		this.genero = genero;
	}


	public Integer getIsbn() {
		return isbn;
	}


	public void setIsbn(Integer isbn) {
		this.isbn = isbn;
	}


	@Override
	public String toString() {
		return "Livro [id=" + id + ", titulo=" + titulo + ", autor=" + autor + ", editora=" + editora + ", ano=" + ano
				+ ", paginas=" + paginas + ", genero=" + genero + ", isbn=" + isbn + "]";
	}
	
	

}
