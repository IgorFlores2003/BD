package biblioteca;
import java.util.Scanner;

import javax.persistence.Column;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class StartApp {
	
	static EntityManagerFactory emf = Persistence.createEntityManagerFactory("biblioteca");
	static EntityManager em = emf.createEntityManager();
	static Scanner ler = new Scanner(System.in);
	
	public static void app () {
		int option;
		boolean cond = true;
		
		do {
			menu1();
			
			option = lerInt();
			int c;
			int i;
			
			switch (option) {
				case 1:
					System.out.println("Digite o ID do livro que deseja consultar:");
					c = lerInt();
					if(procurarLivro(c) != null) {
						System.out.println(procurarLivro(c));
						
					} else {
						System.out.println("Não encontrado, tente novamente!!!");
						
					}
					
					
					break;
				
				case 2:
					System.out.println("Digite o CPF do leitor que deseja consultar:");
					c = lerInt();
					if(procurarLeitor(c) != null) {
						System.out.println(procurarLeitor(c));
						
					} else {
						System.out.println("Não encontrado, tente novamente!!!");
						
					}
					
					break;
				
				case 3:
					System.out.println("Digite o código do emprestimo que deseja consultar:");
					c = lerInt();
					if(procurarEmprestimo(c) != null) {
						System.out.println(procurarEmprestimo(c));
						
					} else {
						System.out.println("Não encontrado, tente novamente!!!");
						
					}
					
					
					break;
				
				case 4:
					Livro l1 = new Livro();
					
					System.out.println("Digite o ID:");
					l1.setId(lerInt());
					
					
					System.out.println("Digite o título:");
					l1.setTitulo(ler.nextLine());
					
					
					System.out.println("Digite o autor:");
					l1.setAutor(ler.nextLine());
					
					
					System.out.println("Digite o editora:");
					l1.setEditora(ler.nextLine());
					
					
					
					System.out.println("Digite o Ano:");
					l1.setAno(lerInt());
					
					
					System.out.println("Digite o páginas:");
					l1.setPaginas(lerInt());
					
					
					System.out.println("Digite o genero:");
					l1.setGenero(ler.nextLine());
					
					
					System.out.println("Digite o ISBN:");
					l1.setIsbn(lerInt());
					
					createLivro(l1);
					
					break;
				case 5:
					Leitor le1 = new Leitor();
					
				
					System.out.println("Digite o CPF:");
					le1.setCpf(lerInt());
					
					
					System.out.println("Digite o nome:");
					le1.setNome(ler.nextLine());
					
					
					System.out.println("Digite o telefone:");
					le1.setTelefone(lerInt());
					
				
					System.out.println("Digite o e-mail:");
					le1.setEmail(ler.nextLine());
					
					
					
					System.out.println("Digite o endereço:");
					le1.setEndereco(ler.nextLine());
					
					createLeitor(le1);
					
					break;
				
				case 6:
					Emprestimo e1 = new Emprestimo();
					
					System.out.println("Digite o Código:");
					e1.setCod(lerInt());
					
					
					System.out.println("Digite o id do livro");
					e1.setIdLivro(lerInt());
					
					
					System.out.println("Digite o cpf do leitor:");
					e1.setCpfLeitor(lerInt());
					
					
					System.out.println("Digite data do emprestimo:");
					e1.setEmprestimo(ler.nextLine());
					
					
					System.out.println("Digite data de devolução prevista:");
					e1.setDevolucao(ler.nextLine());
					
					
					System.out.println("Digite o status inicial:");
					e1.setStatus(ler.nextLine());
					
					createEmprestimo(e1);
					
					
					break;
				
				case 7:
					System.out.println("Digite o ID do livro que deseja remover:");
					i = lerInt();
					
					if(procurarLivro(i) != null) {
						removeLivro(procurarLivro(i));
						
					} else {
						System.out.println("Não encontrado, tente novamente!!!");
						
					}
					
					break;
				
				case 8:
					System.out.println("Digite o CPF do leitor que deseja remover:");
					i = lerInt();
					
					if(procurarLeitor(i) != null) {
						removeLeitor(procurarLeitor(i));
						
					} else {
						System.out.println("Não encontrado, tente novamente!!!");
						
					}
					
					break;
				
				case 9:
					System.out.println("Digite o código do emprestimo que deseja remover:");
					i = lerInt();
					
					if(procurarEmprestimo(i) != null) {
						removeEmprestimo(procurarEmprestimo(i));
						
					} else {
						System.out.println("Não encontrado, tente novamente!!!");
						
					}
					
					
					break;
				case 10:
					cond = false;
					System.out.println("Até!");
					
					break;

				default:
					System.out.println("Opção não existe");
					break;
			}
			
		} while (cond);
		
	}
	

	public static void menu1 () {
		System.out.println("############## Biblioteca ##############");
		System.out.println("Qual operação você deseja realizar?		");
		System.out.println("1 -> Consultar Livro					");
		System.out.println("2 -> Consultar Leitor					");
		System.out.println("3 -> Consultar Emprestimo				");
		System.out.println("4 -> Adicionar Livro					");
		System.out.println("5 -> Adicionar Leitor					");
		System.out.println("6 -> Adicionar Emprestimo				");
		System.out.println("7 -> Remover Livro						");
		System.out.println("8 -> Remover Leitor						");
		System.out.println("9 -> Remover Emprestimo					");
		System.out.println("Digite '10' para sair.					");
		System.out.println("########################################");
		
	}
	
	public static int lerInt() {
		int value = ler.nextInt();
		ler.nextLine();
		
		return value; 
	}
	
	public static void main(String[] args) {
		app();
		ler.close();
		em.close();
		emf.close();
	}
	
	public static void createLivro (Livro l1) {

		em.getTransaction().begin();
		em.persist(l1);
		em.getTransaction().commit();
		
		System.out.println("Livro criado!!!");
		
	}
	
	public static void createLeitor (Leitor le1) {

		em.getTransaction().begin();
		em.persist(le1);
		em.getTransaction().commit();
		
		System.out.println("Leitor criado!!!");
		
	}
	
	public static void createEmprestimo (Emprestimo e1) {
		em.getTransaction().begin();
		em.persist(e1);
		em.getTransaction().commit();
		
		System.out.println("Emprestimo criado!!!");
		
	}
	
	public static Livro procurarLivro (Integer id) {
		return em.find(Livro.class, id);	
	}
	
	public static Leitor procurarLeitor (Integer cpf) {
		return em.find(Leitor.class, cpf);
	}
	
	public static Emprestimo procurarEmprestimo (Integer cod) {
		return em.find(Emprestimo.class, cod);
	}
	
	public static void removeLivro (Livro l1) {
		em.getTransaction().begin();
		em.remove(l1);
		em.getTransaction().commit();
		
		System.out.println("Livro removido!!!");
	}
	
	public static void removeLeitor (Leitor le1) {
		em.getTransaction().begin();
		em.remove(le1);
		em.getTransaction().commit();
		
		System.out.println("Leitor removido!!!");
	}
	
	public static void removeEmprestimo (Emprestimo e1) {
		em.getTransaction().begin();
		em.remove(e1);
		em.getTransaction().commit();
		
		System.out.println("Emprestimo concluido!!!");
	}


}

/*    Collection<Professor> emps = service.findAllProfessors();
    for (Professor e : emps)
      System.out.println("Found Professor: " + e);*/

