package biblioteca;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Emprestimo {
	
	@Id
	private Integer cod;
	@Column(name="ID do Livro")
	private Integer idLivro;
	@Column(name="CPF do Leitor")
	private Integer cpfLeitor;
	@Column(name="Data do Emprestimo")
	private String emprestimo;
	@Column(name="Data Devolução Estimada")
	private String devolucao;
	@Column(name="Data de Prorrogação")
	private String prorrogacao;
	@Column(name="Data Devolução Efetiva")
	private String devolucaoEfet;
	@Column(name="Status")
	private String status;
	@Column(name="Multa")
	private Integer multa;
	
	public Emprestimo () {
		
		
	}

	public Emprestimo(Integer cod, Integer idLivro, Integer cpfLeitor, String emprestimo, String devolucao,
			String prorrogacao, String devolucaoEfet, String status, Integer multa) {
		super();
		this.cod = cod;
		this.idLivro = idLivro;
		this.cpfLeitor = cpfLeitor;
		this.emprestimo = emprestimo;
		this.devolucao = devolucao;
		this.prorrogacao = prorrogacao;
		this.devolucaoEfet = devolucaoEfet;
		this.status = status;
		this.multa = multa;
	}

	public Integer getCod() {
		return cod;
	}

	public void setCod(Integer cod) {
		this.cod = cod;
	}

	public Integer getIdLivro() {
		return idLivro;
	}

	public void setIdLivro(Integer idLivro) {
		this.idLivro = idLivro;
	}

	public Integer getCpfLeitor() {
		return cpfLeitor;
	}

	public void setCpfLeitor(Integer cpfLeitor) {
		this.cpfLeitor = cpfLeitor;
	}

	public String getEmprestimo() {
		return emprestimo;
	}

	public void setEmprestimo(String emprestimo) {
		this.emprestimo = emprestimo;
	}

	public String getDevolucao() {
		return devolucao;
	}

	public void setDevolucao(String devolucao) {
		this.devolucao = devolucao;
	}

	public String getProrrogacao() {
		return prorrogacao;
	}

	public void setProrrogacao(String prorrogacao) {
		this.prorrogacao = prorrogacao;
	}

	public String getDevolucaoEfet() {
		return devolucaoEfet;
	}

	public void setDevolucaoEfet(String devolucaoEfet) {
		this.devolucaoEfet = devolucaoEfet;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getMulta() {
		return multa;
	}

	public void setMulta(Integer multa) {
		this.multa = multa;
	}

	@Override
	public String toString() {
		return "Emprestimo [cod=" + cod + ", idLivro=" + idLivro + ", cpfLeitor=" + cpfLeitor + ", emprestimo="
				+ emprestimo + ", devolucao=" + devolucao + ", prorrogacao=" + prorrogacao + ", devolucaoEfet="
				+ devolucaoEfet + ", status=" + status + ", multa=" + multa + "]";
	}
	
	
	

}
